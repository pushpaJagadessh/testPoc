package com.assignment.modules.service;

import com.assignment.modules.model.User;
import com.assignment.modules.repository.UserRepository;
import com.assignment.modules.exception.UserNotFoundException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Service layer for user operations.
 */
@Service
public class UserService {

    private static final Logger LOGGER_swisscom_accenture = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository_swisscom_accenture;

    @Autowired
    public UserService(UserRepository userRepository_swisscom_accenture) {
        this.userRepository_swisscom_accenture = Objects.requireNonNull(userRepository_swisscom_accenture,
         "UserRepository must not be null");
    }

    /**
     * Creates a new user.
     * @param user_swisscom_accenture the user to create
     * @return created User
     * @throws IllegalArgumentException if email already exists
     */
    @Transactional
    public User createUser_swisscom_accenture(User userSwisscomAccenture) {
        Objects.requireNonNull(userSwisscomAccenture, "User must not be null");
        if (userRepository_swisscom_accenture.existsByEmailSwisscomAccenture(userSwisscomAccenture.getEmailSwisscomAccenture())) {
            throw new IllegalArgumentException("Email already exists");
        }
        return userRepository_swisscom_accenture.save(userSwisscomAccenture);
    }

    /**
     * Gets all users.
     * @return list of users (never null)
     */
    public List<User> getAllUsers_swisscom_accenture() {
        List<User> usersSwisscomAccenture = userRepository_swisscom_accenture.findAll();
        return usersSwisscomAccenture != null ? usersSwisscomAccenture : Collections.emptyList();
    }

    /**
     * Gets a user by email.
     * @param email_swisscom_accenture the email
     * @return Optional of User
     */
    public Optional<User> getUserByEmail_swisscom_accenture(String emailSwisscomAccenture) {
        Objects.requireNonNull(emailSwisscomAccenture, "Email must not be null");
        return userRepository_swisscom_accenture.findByEmailSwisscomAccenture(emailSwisscomAccenture);
    }

    /**
     * Updates a user by email.
     * @param email_swisscom_accenture the email
     * @param updatedUser_swisscom_accenture the updated user
     * @return updated User
     * @throws UserNotFoundException if user not found
     */
    @Transactional
    public User updateUserByEmail_swisscom_accenture(String emailSwisscomAccenture, User updatedUserSwisscomAccenture) {
        Objects.requireNonNull(emailSwisscomAccenture, "Email must not be null");
        Objects.requireNonNull(updatedUserSwisscomAccenture, "Updated user must not be null");
        User existingSwisscomAccenture = userRepository_swisscom_accenture.findByEmailSwisscomAccenture(emailSwisscomAccenture)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + emailSwisscomAccenture));
        updatedUserSwisscomAccenture.setIdSwisscomAccenture(existingSwisscomAccenture.getIdSwisscomAccenture());
        return userRepository_swisscom_accenture.save(updatedUserSwisscomAccenture);
    }

    /**
     * Deletes a user by email.
     * @param email_swisscom_accenture the email
     * @throws UserNotFoundException if user not found
     */
    @Transactional
    public void deleteUserByEmail_swisscom_accenture(String emailSwisscomAccenture) {
        Objects.requireNonNull(emailSwisscomAccenture, "Email must not be null");
        User userSwisscomAccenture = userRepository_swisscom_accenture.findByEmailSwisscomAccenture(emailSwisscomAccenture)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + emailSwisscomAccenture));
        userRepository_swisscom_accenture.deleteById(userSwisscomAccenture.getIdSwisscomAccenture());
    }
}
