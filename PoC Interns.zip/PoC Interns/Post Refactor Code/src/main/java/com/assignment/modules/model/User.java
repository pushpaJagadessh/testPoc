package com.assignment.modules.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

/**
 * User entity.
 */
@Document(collection = "users")
public class User {
    @Id
    private String idSwisscomAccenture;

    @NotNull(message = "Name must not be null")
    private String nameSwisscomAccenture;

    @NotNull(message = "Email must not be null")
    @Email(message = "Email should be valid")
    private String emailSwisscomAccenture;

    private int ageSwisscomAccenture;

    public String getIdSwisscomAccenture() {
        return idSwisscomAccenture;
    }

    public void setIdSwisscomAccenture(String idSwisscomAccenture) {
        this.idSwisscomAccenture = idSwisscomAccenture;
    }

    public String getNameSwisscomAccenture() {
        return nameSwisscomAccenture;
    }

    public void setNameSwisscomAccenture(String nameSwisscomAccenture) {
        this.nameSwisscomAccenture = nameSwisscomAccenture;
    }

    public String getEmailSwisscomAccenture() {
        return emailSwisscomAccenture;
    }

    public void setEmailSwisscomAccenture(String emailSwisscomAccenture) {
        this.emailSwisscomAccenture = emailSwisscomAccenture;
    }

    public int getAgeSwisscomAccenture() {
        return ageSwisscomAccenture;
    }

    public void setAgeSwisscomAccenture(int ageSwisscomAccenture) {
        this.ageSwisscomAccenture = ageSwisscomAccenture;
    }

    @Override
    public String toString() {
        return "User{" +
                "id='" + idSwisscomAccenture + '\'' +
                ", name='" + nameSwisscomAccenture + '\'' +
                ", email='" + emailSwisscomAccenture + '\'' +
                ", age=" + ageSwisscomAccenture +
                '}';
    }

    public User() {}

    public User(String idSwisscomAccenture, String nameSwisscomAccenture, String emailSwisscomAccenture, int ageSwisscomAccenture) {
        this.idSwisscomAccenture = idSwisscomAccenture;
        this.nameSwisscomAccenture = nameSwisscomAccenture;
        this.emailSwisscomAccenture = emailSwisscomAccenture;
        this.ageSwisscomAccenture = ageSwisscomAccenture;
    }
}
