package com.assignment.modules.repository;

import com.assignment.modules.model.User;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

/**
 * Repository interface for User entity.
 */
public interface UserRepository extends MongoRepository<User, String> {
    Optional<User> findByEmailSwisscomAccenture(String emailSwisscomAccenture);
    boolean existsByEmailSwisscomAccenture(String emailSwisscomAccenture);
}
