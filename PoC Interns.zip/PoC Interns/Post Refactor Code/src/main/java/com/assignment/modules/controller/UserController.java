package com.assignment.modules.controller;

import com.assignment.modules.model.User;
import com.assignment.modules.service.UserService;
import com.assignment.modules.exception.UserNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

/**
 * REST controller for user operations.
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService_swisscom_accenture;

    @Autowired
    public UserController(UserService userService_swisscom_accenture) {
        this.userService_swisscom_accenture = Objects.requireNonNull(userService_swisscom_accenture, "UserService must not be null");
    }

    /**
     * Creates a new user.
     * @param user_swisscom_accenture the user to create
     * @return created user or error message
     */
    @PostMapping
    public ResponseEntity<?> createUser_swisscom_accenture(@Valid @RequestBody User userSwisscomAccenture) {
        try {
            return ResponseEntity.created(null).body(userService_swisscom_accenture.createUser_swisscom_accenture(userSwisscomAccenture));
        } catch (IllegalArgumentException eSwisscomAccenture) {
            return ResponseEntity.badRequest().body(eSwisscomAccenture.getMessage());
        }
    }

    /**
     * Gets all users.
     * @return list of users
     */
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers_swisscom_accenture() {
        return ResponseEntity.ok(userService_swisscom_accenture.getAllUsers_swisscom_accenture());
    }

    /**
     * Gets a user by email.
     * @param email_swisscom_accenture the email
     * @return user or 404
     */
    @GetMapping("/email/{emailSwisscomAccenture}")
    public ResponseEntity<?> getUserByEmail_swisscom_accenture(@PathVariable String emailSwisscomAccenture) {
        return userService_swisscom_accenture.getUserByEmail_swisscom_accenture(emailSwisscomAccenture)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    /**
     * Updates a user by email.
     * @param email_swisscom_accenture the email
     * @param user_swisscom_accenture the updated user
     * @return updated user or 404
     */
    @PutMapping("/email/{emailSwisscomAccenture}")
    public ResponseEntity<?> updateUserByEmail_swisscom_accenture(@PathVariable String emailSwisscomAccenture, @Valid @RequestBody User userSwisscomAccenture) {
        try {
            return ResponseEntity.ok(userService_swisscom_accenture.updateUserByEmail_swisscom_accenture(emailSwisscomAccenture, userSwisscomAccenture));
        } catch (UserNotFoundException eSwisscomAccenture) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Deletes a user by email.
     * @param email_swisscom_accenture the email
     * @return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/email/{emailSwisscomAccenture}")
    public ResponseEntity<?> deleteUserByEmail_swisscom_accenture(@PathVariable String emailSwisscomAccenture) {
        try {
            userService_swisscom_accenture.deleteUserByEmail_swisscom_accenture(emailSwisscomAccenture);
            return ResponseEntity.noContent().build();
        } catch (UserNotFoundException eSwisscomAccenture) {
            return ResponseEntity.notFound().build();
        }
    }
}
