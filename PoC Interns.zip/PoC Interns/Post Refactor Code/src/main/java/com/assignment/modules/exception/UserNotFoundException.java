package com.assignment.modules.exception;

/**
 * Exception thrown when a user is not found.
 */
public class UserNotFoundException extends RuntimeException {
    public UserNotFoundException(String message_swisscom_accenture) {
        super(message_swisscom_accenture);
    }
}
